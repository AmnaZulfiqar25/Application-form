package com.example.applicationform;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.util.ArrayList;

public class HelloApplication extends Application {

    // ArrayList to store form data

    private File selectedImage;

    @Override
    public void start(Stage stage) {

        Text formTitle = new Text("Application Form");
        formTitle.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");


        Label nameLabel = new Label("Name:");
        nameLabel.setFont(Font.font("Ariel", 10));
        TextField nameField = new TextField();

        Label fatherNameLabel = new Label("Father's Name:");
        TextField fatherNameField = new TextField();

        Label emailLabel = new Label("Email:");
        TextField emailField = new TextField();

        Label cityLabel = new Label("City:");
        ComboBox<String> cityComboBox = new ComboBox<>();
        cityComboBox.getItems().addAll("New York", "Los Angeles", "Chicago", "Houston", "Phoenix");
        cityComboBox.setPromptText("Select City");

        Label genderLabel = new Label("Gender:");
        ToggleGroup genderGroup = new ToggleGroup();
        RadioButton maleRadio = new RadioButton("Male");
        RadioButton femaleRadio = new RadioButton("Female");
        maleRadio.setToggleGroup(genderGroup);
        femaleRadio.setToggleGroup(genderGroup);

        Label imageLabel = new Label("Profile Picture:");
        Button uploadButton = new Button("Upload Image");
        ImageView imageView = new ImageView();
        imageView.setFitWidth(100);
        imageView.setFitHeight(100);

        uploadButton.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg"));
            selectedImage = fileChooser.showOpenDialog(stage);
            if (selectedImage != null) {
                Image image = new Image(selectedImage.toURI().toString());
                imageView.setImage(image);
            }
        });


        // Buttons
        Button submitButton = new Button("Submit");
        Button cancelButton = new Button("Cancel");

        cancelButton.setOnAction(e -> stage.close());

        submitButton.setOnAction(e -> {
            String name = nameField.getText();
            String fatherName = fatherNameField.getText();
            String email = emailField.getText();
            String city = cityComboBox.getValue();
            String gender = ((RadioButton) genderGroup.getSelectedToggle()).getText();
            String imagePath = selectedImage != null ? selectedImage.getAbsolutePath() : "No image selected";

            // Store the data
            userDataList.add(new UserData(name, fatherName, email, city, gender, imagePath));

            // Show the new form
            displaySubmittedData();
        });



        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(20));
        gridPane.setVgap(15);
        gridPane.setHgap(10);

        HBox datePickerBox= new HBox();
        datePickerBox.setBorder(new Border(new BorderStroke(Color.BLUE, // Border color
                BorderStrokeStyle.SOLID, // Border style
                new CornerRadii(5), // Rounded corners
                new BorderWidths(2) // Border width)
        )));
        Label dateLabel= new Label("Date of Submission:");
        DatePicker datePicker= new DatePicker();
        datePickerBox.getChildren().addAll(dateLabel, datePicker);
        gridPane.add(datePickerBox,1,7);


        gridPane.add(formTitle, 0, 0, 2, 1);
        gridPane.add(nameLabel, 0, 1);
        gridPane.add(nameField, 1, 1);
        gridPane.add(fatherNameLabel, 0, 2);
        gridPane.add(fatherNameField, 1, 2);
        gridPane.add(emailLabel, 0, 3);
        gridPane.add(emailField, 1, 3);
        gridPane.add(cityLabel, 0, 4);
        gridPane.add(cityComboBox, 1, 4);
        gridPane.add(genderLabel, 0, 5);
        HBox genderBox = new HBox(10, maleRadio, femaleRadio);
        gridPane.add(genderBox, 1, 5);
        gridPane.add(imageLabel, 0, 6);
        HBox imageBox = new HBox(10, uploadButton, imageView);
        gridPane.add(imageBox, 1, 6);

        HBox buttonBox = new HBox(10, submitButton, cancelButton);
        buttonBox.setAlignment(Pos.BOTTOM_RIGHT);
        gridPane.add(buttonBox, 1, 8);

        gridPane.setAlignment(Pos.CENTER);

        // Scene and Stage
        Scene scene = new Scene(gridPane, 600, 500);
        stage.setTitle("Application Form");
        stage.setScene(scene);
        stage.show();
    }
    private final ArrayList<UserData> userDataList = new ArrayList<>();
    // Method to display submitted data
    private void displaySubmittedData() {
        Stage displayStage = new Stage();
        VBox vbox = new VBox(15);
        vbox.setPadding(new Insets(20));

        for (UserData data : userDataList) {
            Label userLabel = new Label(
                    "Name: " + data.getName() + "\n" +
                            "Father's Name: " + data.getFatherName() + "\n" +
                            "Email: " + data.getEmail() + "\n" +
                            "City: " + data.getCity() + "\n" +
                            "Gender: " + data.getGender() + "\n" +
                            "Image Path: " + data.getImagePath()
            );
            userLabel.setStyle("-fx-font-size: 14px; -fx-border-color: black; -fx-padding: 10px;");
            vbox.getChildren().add(userLabel);
        }

        Scene scene = new Scene(vbox, 400, 300);
        displayStage.setTitle("Submitted Data");
        displayStage.setScene(scene);
        displayStage.show();
    }

    // UserData class to store user information
    private static class UserData {
        private final String name;
        private final String fatherName;
        private final String email;
        private final String city;
        private final String gender;
        private final String imagePath;

        public UserData(String name, String fatherName, String email, String city, String gender, String imagePath) {
            this.name = name;
            this.fatherName = fatherName;
            this.email = email;
            this.city = city;
            this.gender = gender;
            this.imagePath = imagePath;
        }

        public String getName() {
            return name;
        }

        public String getFatherName() {
            return fatherName;
        }

        public String getEmail() {
            return email;
        }

        public String getCity() {
            return city;
        }

        public String getGender() {
            return gender;
        }

        public String getImagePath() {
            return imagePath;
        }
    }

    public static void main(String[] args) {
        launch();
    }
}






//GPT code

//
//import javafx.application.Application;
//import javafx.geometry.Insets;
//import javafx.geometry.Pos;
//import javafx.scene.Scene;
//import javafx.scene.control.Button;
//import javafx.scene.control.Label;
//import javafx.scene.control.TextField;
//import javafx.scene.layout.GridPane;
//import javafx.scene.text.Text;
//import javafx.stage.Stage;
//
//public class HelloApplication extends Application {
//    @Override
//    public void start(Stage stage) {
//        // Title
//        Text formTitle = new Text("Simple Application Form");
//        formTitle.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");
//
//        // Labels and Input Fields
//        Label nameLabel = new Label("Name:");
//        TextField nameField = new TextField();
//
//        Label emailLabel = new Label("Email:");
//        TextField emailField = new TextField();
//
//        Label phoneLabel = new Label("Phone:");
//        TextField phoneField = new TextField();
//
//        // Buttons
//        Button submitButton = new Button("Submit");
//        Button cancelButton = new Button("Cancel");
//
//        cancelButton.setOnAction(e -> stage.close());
//
//        // Layout
//        GridPane gridPane = new GridPane();
//        gridPane.setPadding(new Insets(20)); // Padding around the grid
//        gridPane.setVgap(15); // Vertical gap between rows
//        gridPane.setHgap(10); // Horizontal gap between columns
//
//        // Adding elements to the grid
//        gridPane.add(formTitle, 0, 0, 2, 1); // Title spans two columns
//        gridPane.add(nameLabel, 0, 1);
//        gridPane.add(nameField, 1, 1);
//        gridPane.add(emailLabel, 0, 2);
//        gridPane.add(emailField, 1, 2);
//        gridPane.add(phoneLabel, 0, 3);
//        gridPane.add(phoneField, 1, 3);
//
//        gridPane.add(submitButton, 0, 4);
//        gridPane.add(cancelButton, 1, 4);
//
//        // Align elements
//        gridPane.setAlignment(Pos.CENTER);
//        GridPane.setMargin(submitButton, new Insets(10, 0, 0, 0));
//        GridPane.setMargin(cancelButton, new Insets(10, 0, 0, 0));
//
//        // Scene and Stage
//        Scene scene = new Scene(gridPane, 400, 300);
//        stage.setTitle("Application Form");
//        stage.setScene(scene);
//        stage.show();
//    }
//
//    public static void main(String[] args) {
//        launch();
//    }
//}




// SIR Code
//import javafx.application.Application;
//import javafx.application.Preloader;
//import javafx.fxml.FXMLLoader;
//import javafx.geometry.Insets;
//import javafx.geometry.Pos;
//import javafx.scene.Node;
//import javafx.scene.control.Button;
//import javafx.scene.control.Label;
//import javafx.scene.control.PasswordField;
//import javafx.scene.control.TextField;
//import javafx.scene.Scene;
//import javafx.scene.layout.FlowPane;
//import javafx.scene.layout.GridPane;
//import javafx.scene.layout.HBox;
//import javafx.scene.layout.StackPane;
//import javafx.scene.text.Text;
//import javafx.stage.Stage;
//import java.awt.*;
//import java.io.IOException;
//public class HelloApplication  extends Application {
//    @Override
//    public void start(Stage stage) throws IOException {
//        // layout
//        Text welcomeText=new Text("Application Form");
//        welcomeText.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");
//        Label userlabel = new Label("Name");
//        Label passwordLabel = new Label("Father Name");
//
//        TextField userNameText = new TextField();
//        TextField fatherName = new TextField();
//        Button submitButton = new Button("Submit");
//        PasswordField passwordField=new PasswordField();
//        Button submit = new Button("submit");
//        Button cancel = new Button("Cancel");
//
//        GridPane gridPane = new GridPane();
//        gridPane.add(welcomeText,0,0,2,1);
//        gridPane.setPadding(new Insets(10,10,10,10));
//        gridPane.setVgap(10);
//        gridPane.setVgap(10);
//        HBox hbox = new HBox();
//        hbox.getChildren().addAll(submit, cancel);
//        hbox.getChildren().addAll(userNameText,fatherName);
//        hbox.setAlignment(Pos.BOTTOM_RIGHT);
//        hbox.setSpacing(10);
//        cancel.setOnAction(e-> stage.hide());
//        gridPane.add(userlabel,0,1);
//        gridPane.add(userNameText,1,1);
//        gridPane.add(passwordLabel,0,2);
//        gridPane.add(fatherName,1,2);
//        gridPane.add(hbox,1,3);
//        //gridPane.add(cancel,2,3);
//
//        Scene scene = new Scene(gridPane,500,500);
//        stage.setScene(scene);
//        stage.show();
//    }
//    public static void main(String[] args) {
//        launch();
//    }
//}


//My code

//import javafx.application.Application;
//import javafx.fxml.FXMLLoader;
//import javafx.geometry.Insets;
//import javafx.scene.Scene;
//import javafx.scene.layout.GridPane;
//import javafx.scene.layout.HBox;
//import javafx.scene.text.Font;
//import javafx.stage.Stage;
//import javafx.scene.text.Text;
//import javafx.scene.control.Label;
//import javafx.scene.control.TextField;
//import javafx.scene.control.Button;
//import javafx.scene.layout.BorderPane;
//import java.awt.*;
//import java.io.IOException;
//
//public class HelloApplication extends Application {
//    @Override
//    public void start(Stage stage) throws IOException {
//        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
//        GridPane gridPane = new GridPane();
//        gridPane.setHgap(10);
//        gridPane.setVgap(10);
//        gridPane.setPadding(new Insets(10,10,10,10));
//
//
//        Scene scene1 = new Scene(fxmlLoader.load(), 320, 240);
//        Text welcomeText = new Text("Welcome to application form!");
//        welcomeText.setFont(Font.font(15));
//        gridPane.add(welcomeText, 0, 0, 2, 1);
//
//        Label usernameLabel1 = new Label("Username: ");
//        gridPane.add(usernameLabel1,0,1);
//
//        TextField usernameTextField = new TextField();
//        gridPane.add(usernameTextField,1,1);
//
//        Button button = new Button("Submit");
//        Button cancelButton = new Button("Cancel");
//
//        cancelButton.setOnAction(e -> System.exit(0));
//        HBox hbox = new HBox();
//        hbox.setSpacing(10);
//        hbox.getChildren().addAll(button,cancelButton);
//        gridPane.add(hbox,1,2);
//
//        Scene scene = new Scene(gridPane, 320, 240);
//        stage.setTitle("Hello Application");
//        stage.setScene(scene);
//        stage.show();
//    }
//
//    public static void main(String[] args) {
//        launch();
//    }
//}