private static class UserData {
    private final String name;
    private final String fatherName;
    private final String email;
    private final String city;
    private final String gender;
    private final String imagePath;
    public UserData(String name, String fatherName, String email, String city, String gender, String imagePath) {
        this.name = name;
        this.fatherName = fatherName;
        this.email = email;
        this.city = city;
        this.gender = gender;
        this.imagePath = imagePath;
    }
    public String getName() {        return name;    }
    public String getFatherName() {        return fatherName;    }
    public String getEmail() {        return email;}
    public String getCity() {        return city;}
    public String getGender() {        return gender;    }
    public String getImagePath() {        return imagePath;    }
}
